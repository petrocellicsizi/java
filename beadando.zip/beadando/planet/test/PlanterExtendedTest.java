package planet.test;

import planet.*;
import planet.plant.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class PlanterExtendedTest{
    @Test
    public void init2(){
        int[]x=new int[]{1,2,3,4,5,6,7,8};
        int[]y=new int[]{1,2,6,4,5,6,7,8};
        Planter p = new Planter(x);
        p.growPlants();
        assertArrayEquals(y,p.getPlantCounts());
    }
    @Test
    public void encapsulation(){
        int[]counts=new int[]{1,2,3,4,5,6,7,8};
        int[]x=new int[]{1,2,3,4,5,6,7,8};
        Planter p = new Planter(counts);
        counts[1]=100;
        int[]counts2=p.getPlantCounts();
        counts[4]=200;
        assertArrayEquals(x,p.getPlantCounts());
    }
    @Test
    public void init3(){
        int[]x={1,2,3,4,5,6,7,8};
        int[]y={1,2,3,4,10,6,7,8};
        Planet q =(Planet.JUPITER);
        Planter p = new Planter(x,q);
        p.growPlants();
        assertArrayEquals(y,p.getPlantCounts());
    }
}