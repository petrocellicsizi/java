package planet.test;

import planet.*;
import planet.plant.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


public class PlanetCompulsoryTest{
    @Test
    public void init(){
        Planter p = new Planter();
        assertEquals(100,p.getPlantCount(Planet.EARTH));
        assertEquals(0,p.getPlantCount(Planet.SATURN));
        assertEquals(0,p.getPlantCount(Planet.URANUS));
    }
    @Test
    public void addPlant(){
        Planter p = new Planter();
        p.addPlant(Planet.EARTH);
        assertEquals(101,p.getPlantCount(Planet.EARTH));
        assertEquals(0,p.getPlantCount(Planet.SATURN));
        assertEquals(0,p.getPlantCount(Planet.URANUS));
    }
    @Test
    public void growOnEarth(){
        Planter p = new Planter();
        p.growPlants();
        assertEquals(200,p.getPlantCount(Planet.EARTH));
        assertEquals(0,p.getPlantCount(Planet.SATURN));
        assertEquals(0,p.getPlantCount(Planet.URANUS));
    }
    @Test
    public void growMoveThenGrow(){
        Planet s =(Planet.NEPTUNE);
        int[]x={0,0,100,0,0,0,0,0};
        Planter p = new Planter(x,s);
        Planet n = (Planet.NEPTUNE);
        Planet f =(Planet.EARTH);
        Planet m =(Planet.MARS);
        p.movePlants(30,f,m);
        p.movePlants(20,f,n);
        p.movePlants(15,m,n);
        p.growPlants();
        assertEquals(50,p.getPlantCount(Planet.EARTH));
        assertEquals(70,p.getPlantCount(Planet.NEPTUNE));
        assertEquals(15,p.getPlantCount(Planet.MARS));
    }
}